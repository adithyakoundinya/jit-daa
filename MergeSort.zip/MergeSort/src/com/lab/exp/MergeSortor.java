package com.lab.exp;

import java.util.ArrayList;
import java.util.Comparator;
/**
 * 1. A Divide and Conquer technique is used to sort the objects.
 * 2. Comparator that is passed while creating instance of this class is used for basic comparison.
 * @author Adithya
 * @param <T> This can be any object that is under focus to sort.
 */
public class MergeSortor<T> implements Sorter<T>
{
	    private ArrayList<T> array;
	    private ArrayList<T> tempMergArr;
	    private int length;
	    private Comparator<T> comparator;
	    
	    public MergeSortor(ArrayList<T> inputArr, Comparator<T> comp)
	    {
	    	this.array = inputArr;
	        this.length = inputArr.size();
	        this.tempMergArr = new ArrayList<T>();
	        for(T element: array)
	        {
	        	tempMergArr.add(element);
	        }
	        this.comparator = comp;
	    }
	   /**
	    * sort method is declared in the interface Sorter. 
	    * Implementation of sort method is mandatory.
	    * @author Adithya B
	    * @return Sorted ArrayList of Objects
	    *  
	    */
	   @Override 
	   public ArrayList<T> sort() 
	   {
	        doMergeSort(0, this.length-1);
	        return array;
	   }
	 
	    private void doMergeSort(int lowerIndex, int higherIndex) {
	         
	    	int middle;
	    	if (lowerIndex < higherIndex) 
	        {
	            middle = (lowerIndex + higherIndex) / 2;
	            // Below step sorts the left side of the array
	            doMergeSort(lowerIndex, middle);
	            // Below step sorts the right side of the array
	            doMergeSort(middle + 1, higherIndex);
	            // Now merge both sides
	            mergeParts(lowerIndex, middle, higherIndex);
	        }
	    }
	 
	    private void mergeParts(int lowerIndex, int middle, int higherIndex) 
	    {
	 
	        for (int i = lowerIndex; i <= higherIndex; i++) 
	        {
	            tempMergArr.set(i,array.get(i));
	        }
	        int i = lowerIndex;
	        int j = middle + 1;
	        int k = lowerIndex;
	        while (i <= middle && j <= higherIndex) 
	        {
	        	int flag = comparator.compare(tempMergArr.get(i),tempMergArr.get(j));            
	        	if (flag<=0) 
		    	{
	                	array.set(k, tempMergArr.get(i));
	                	i++;
	            } 
	        	else
	        	{
	                array.set(k, tempMergArr.get(j));
	                j++;
	            }
	            k++;
	        }
	        while (i <= middle) 
	        {
	            array.set(k, tempMergArr.get(i));
	            k++;
	            i++;
	        }
	    }
}
