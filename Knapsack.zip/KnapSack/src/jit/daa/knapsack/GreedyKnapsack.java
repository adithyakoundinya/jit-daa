package jit.daa.knapsack;

public class GreedyKnapsack 
{
	    
		private int n;
		private int m;
		private int[][] array;
		
		public GreedyKnapsack(int n, int m, int[][] array) 
		{
			this.n=n;
			this.m=m;
			this.array=array;
		}
		
		public void greedy()
	    {
	    	float sum=0,max;
	    	int i,j=0;
	    	while(m>=0)  
	        {  
	            max=0;  
	            for(i=0;i<n;i++)  
	            {  
	                if(((float)array[1][i])/((float)array[0][i])>max)  
	                {  
	                    max=((float)array[1][i])/((float)array[0][i]);  
	                    j=i;  
	                }  
	            }  
	            if(array[0][j]>m)  
	            {  
	                System.out.println("Quantity of item number: " +  (j+1) + " added is " +(float)m/array[0][j]);  
	                sum+=m*max;  
	                m=-1;  
	            }  
	            else  
	            {  
	                System.out.println("Quantity of item number: " + (j+1) + " added fully ");/* + array[0][j]);*/  
	                m-=array[0][j];  
	                sum+=(float)array[1][j];  
	                array[1][j]=0;  
	            }  
	        }  
	        System.out.println("The total profit is " + sum);
	    }
	}