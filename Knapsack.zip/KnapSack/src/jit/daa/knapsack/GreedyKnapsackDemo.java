package jit.daa.knapsack;

import java.io.IOException;
import java.util.Scanner;

public class GreedyKnapsackDemo 
{
    public static void main(String args[]) throws IOException  
    {  
        int i,max_qty,m,n;  
        
        Scanner sc = new Scanner(System.in);
        int array[][]=new int[2][20];  
        System.out.println("Enter no of items");  
        n=sc.nextInt(); 
 
        System.out.println("Enter the weights of each items");
        for(i=0;i<n;i++)  
            array[0][i]=sc.nextInt();    
 
        System.out.println("Enter the values of each items");
        for(i=0;i<n;i++)  
            array[1][i]=sc.nextInt(); 

        System.out.println("Enter maximum volume of knapsack :");  
        max_qty=sc.nextInt();  
        
        m=max_qty;
        
        GreedyKnapsack gks = new GreedyKnapsack(n, m, array);
        gks.greedy();
        sc.close();
    }  

}
