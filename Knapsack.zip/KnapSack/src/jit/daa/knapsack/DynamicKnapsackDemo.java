package jit.daa.knapsack;

import java.util.Scanner;

public class DynamicKnapsackDemo
{
	public static void main (String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
 
        System.out.println("Enter number of elements ");
        int n = scanner.nextInt();
 
        int[] wt = new int[n + 1];
        int[] val = new int[n + 1];
 
        System.out.println("Enter weight for "+ n +" elements");
        for (int i = 1; i <= n; i++)
            wt[i] = scanner.nextInt();
        System.out.println("Enter value for "+ n +" elements");
        for (int i = 1; i <= n; i++)
            val[i] = scanner.nextInt();
 
        System.out.println("Enter knapsack weight ");
        int m = scanner.nextInt();
        DynamicKnapsack ks = new DynamicKnapsack(wt, val, m, n);
        
        ks.process();
        System.out.println(ks);
        scanner.close();
    }

}
