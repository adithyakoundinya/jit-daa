package com.lab.exp;

import java.util.ArrayList;

public interface Sorter<T> 
{
	public ArrayList<T> sort();
}
