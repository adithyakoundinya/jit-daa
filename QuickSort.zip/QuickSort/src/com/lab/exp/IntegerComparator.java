package com.lab.exp;

import java.util.Comparator;

/**
 * This is a Comparator class that implements a generic Comparator interface.
 * The main objective of this class is to implement compare functionality 
 * between the objects in focus.
 * @author Adithya B
 */

public class IntegerComparator implements Comparator<Integer> 
{
	/**
	 * @author Adithya B
	 * @return Integer value -1 if arg0<arg1; 0 if arg0==arg1; 1 if arg0>arg1 
	 * 
	 */
	@Override
	public int compare(Integer arg0, Integer arg1) 
	{
		return arg0.compareTo(arg1);
	}

}
