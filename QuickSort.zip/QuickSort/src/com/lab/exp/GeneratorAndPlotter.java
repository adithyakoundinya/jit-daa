package com.lab.exp;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Random;

/**
 * The class is a utility class for implemention of generating random numbers and also plotting the graph
 * @author Adithya
 */

public class GeneratorAndPlotter 
{
	/**
	 * This static method generates as many random numbers as specified in the argument
	 * and returns an ArrayList of generated numbers
	 * @param maxValue
	 * @return ArrayList of maxValue Integers generated 
	 */
	public static ArrayList<Integer> generateNIntegerInput(int maxValue)
	{
		Random r = new Random();
		ArrayList<Integer> array = new ArrayList<Integer>();
		for (int i=0;i<maxValue;i++)
		{
			array.add(r.nextInt());
		}
		return array;
	}
	
	/**
	 * This Static Method of GeneratorAndPlotter plots a beautiful graph using
	 * xgraph tool for the data that is passed as ArrayList<Long>
	 * @param ArrayList<Long> graphData
	 * @exception {@FileNotFoundException} and {@link UnsupportedEncodingException}
	 * 
	 */
	public static void plotGraph(ArrayList<Long> graphData,String title,String x_axis,String y_axis)
	{
		PrintWriter writer = null;
		try 
		{
			writer = new PrintWriter("/home/adithya/graphSort.txt", "UTF-8");
		} 
		catch (FileNotFoundException | UnsupportedEncodingException e1) 
		{
			
			e1.printStackTrace();
		}
		writer.println("title_x = "+x_axis);
		writer.println("title_y = "+y_axis);
		writer.println("title = "+title);
		writer.println("Color=Red");
		for (int i=0;i<graphData.size();i++) 
		{
			writer.println((5+i)*1000+" "+graphData.get(i));
			//System.out.println("NumOfInput = "+(5+i)*1000+", Time Taken = "+graphData.get(i)+" milliseconds");;
		}
		writer.println("Color=Green");
		for (int i=0;i<graphData.size();i++) 
		{
			if(i==0)
			{
				writer.println((5+i)*1000+" 0.0");
			}
			else
				writer.println((5+i)*1000+" "+1000*(3*(i*Math.log(i))/(800*10^6)));
			//System.out.println("NumOfInput = "+(5+i)*1000+", Time Taken = "+graphData.get(i)+" milliseconds");;
		}
		writer.println("Color=Blue");
		for (int i=0;i<graphData.size();i++) 
		{
			if(i==0)
			{
				writer.println((5+i)*1000+" 0.0");
			}
			else
				writer.println((5+i)*1000+" "+Math.log(i));
			//System.out.println("NumOfInput = "+(5+i)*1000+", Time Taken = "+graphData.get(i)+" milliseconds");;
		}
		
		writer.close();
		
		try {
			Runtime.getRuntime().exec("/home/adithya/XGraph4.30_linux64/bin/xgraph -P /home/adithya/graphSort.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
