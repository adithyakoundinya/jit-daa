package com.lab.exp;

import java.util.ArrayList;

/**
 * The Program is a Main program. In an attempt to demonstrate quick sorting and 
 * calculating its time complexity in an Object Oriented manner. Also, we plot a graph
 * of out findings for input space ranging from 5000 to 100000 in increment of 1000
 * Psudo Code: 
 * Step 1: Generate Random numbers of i numbers
 * Step 2: Start Timer
 * Step 3: Quick Sort the vaues
 * Step 4: Stop Timer
 * Step 5: Save the Time_Taken for sorting in a ArrayList
 * Step 6: go to step 1 until i == 100000
 * Step 7: Plot a graph for the save ArrayList
 * @author Adithya B
 */

public class MainClass 
{
	public static void main(String[] args)
	{
		ArrayList<Long> graphData = new ArrayList<Long>();
		//Executing Merge Sort for 5 different values of INPUT starting from 5000 to 10000
		for(int i=5000;i<=100000;i=i+1000)
		{
			//Calls static generateIntegerInputs(i) method from GeneratorAndPlotter class
			ArrayList<Integer> array= GeneratorAndPlotter.generateNIntegerInput(i);
			//Initialize mergeSortor Object and pass integer array along with comparator to constructor
			QuickSortor<Integer> quickSorter = new QuickSortor<Integer>(array, new IntegerComparator());
			//Time Complexity starts
			long startTime = System.currentTimeMillis();
			//Calling Merge Sort
			quickSorter.sort();
			// Time Complexity ends
			long endTime = System.currentTimeMillis();
			//Compute Time push the data to a ArrayList called "graphData"
			graphData.add(endTime-startTime);
		}
		// Called static plotGraph method from GeneratorAndPlotter class
		GeneratorAndPlotter.plotGraph(graphData,"Quick Sorter Time graph","Number of Inputs(n)","Time - ms");
	}
}
