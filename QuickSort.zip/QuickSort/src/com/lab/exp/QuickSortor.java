package com.lab.exp;
import java.util.ArrayList;
import java.util.Comparator;

public class QuickSortor<T> implements Sorter<T>
{
	Comparator<T> comp;
	ArrayList<T> array;
	
	public QuickSortor(ArrayList<T> array,Comparator<T> comp) 
	{
		this.comp = comp;
		this.array = array;
	}
	/**
	    * sort method is declared in the interface Sorter. 
	    * Implementation of sort method is mandatory.
	    * @author Adithya B
	    * @return Sorted ArrayList of Objects
	    *  
	    */
	@Override 
	public ArrayList<T> sort()
	{
		return doQuickSort(0, array.size()-1);
	}
	
	private  ArrayList<T> doQuickSort(int left, int right)
	 {
		int ll=left;
		int rr=right;
		
		if (rr>ll)
		{
			T pivot = array.get((ll+rr)/2);
			while (ll <=rr)
			{
				// that's how we'll use the comparator:
				while(ll<right && comp.compare(array.get(ll), pivot) < 0)
					ll +=1;
				
				while(rr>left &&  comp.compare(array.get(rr), pivot) > 0)
					rr -=1;
				
				if (ll <=rr)
				{
					swap(array, ll ,rr);
					ll +=1;
					rr -=1;
				}
			}
			if (left < rr)
				doQuickSort(left,rr);
			if (ll<right)
				doQuickSort(ll, right);

		}
		return array;
	 }  
	 
	 public void swap(ArrayList<T> arr, int l, int r) {
	        T t = arr.get(l);
	        arr.set(l, arr.get(r));
	        arr.set(r,t);
	    }
}
